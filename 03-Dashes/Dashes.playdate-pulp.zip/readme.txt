Dashes - 8x8.me fill patterns (Pulp).
This work is dedicated to the Public Domain by ACED, licensed under CC0.
https://creativecommons.org/publicdomain/zero/1.0/